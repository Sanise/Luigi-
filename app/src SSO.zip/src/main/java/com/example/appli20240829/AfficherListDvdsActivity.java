package com.example.appli20240829;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;

import java.net.MalformedURLException;
import java.net.URL;

public class AfficherListDvdsActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "Aie";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.afficher_listdvdsactivity);

        // Initialiser le TextView pour afficher les résultats
        TextView textView = findViewById(R.id.TextView);

        // Appeler le service REST pour obtenir la liste des DVDs
        URL urlAAppeler;
        try {
            // Remplacez localhost par l'adresse IP de votre serveur si nécessaire
            urlAAppeler = new URL("http://10.0.2.2:8080/toad/film/all");

            // Démarrer la tâche asynchrone
            new AppelerServiceRestGETAfficherListeDvdsTask(textView).execute(urlAAppeler);

        } catch (MalformedURLException mue) {
            Log.e("mydebug", "URL mal formée: " + mue.toString());
            Toast.makeText(this, "Erreur: URL invalide.", Toast.LENGTH_SHORT).show();
        }
    }
}
